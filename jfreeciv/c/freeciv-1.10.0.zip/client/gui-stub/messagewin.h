/* messagewin.h -- PLACEHOLDER */
#ifndef FC__MESSAGEWIN_H
#define FC__MESSAGEWIN_H

#include "messagewin_g.h"


#endif  /* FC__MESSAGEWIN_H */
