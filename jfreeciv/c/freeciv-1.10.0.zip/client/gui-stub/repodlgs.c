/* repodlgs.c -- PLACEHOLDER */

#include <stdlib.h>

#include "repodlgs.h"


void
report_update_delay_on(void)
{
	/* PORTME */
}

void
report_update_delay_off(void)
{
	/* PORTME */
}

char *
get_report_title(char *report_name)
{
	/* PORTME */
	return NULL;
}

void
update_report_dialogs(void)
{
	/* PORTME */
}

void
science_dialog_update(void)
{
	/* PORTME */
}

void
popup_science_dialog(int make_modal)
{
	/* PORTME */
}

void
trade_report_dialog_update(void)
{
	/* PORTME */
}

void
popup_trade_report_dialog(int make_modal)
{
	/* PORTME */
}

void
activeunits_report_dialog_update(void)
{
	/* PORTME */
}

void
popup_activeunits_report_dialog(int make_modal)
{
	/* PORTME */
}
