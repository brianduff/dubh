/* colors.h -- PLACEHOLDER */
#ifndef FC__COLORS_H
#define FC__COLORS_H

#include "colors_g.h"


#endif  /* FC__COLORS_H */
