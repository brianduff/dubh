/* helpdlg.h -- PLACEHOLDER */
#ifndef FC__HELPDLG_H
#define FC__HELPDLG_H

#include "helpdlg_g.h"


#endif  /* FC__HELPDLG_H */
