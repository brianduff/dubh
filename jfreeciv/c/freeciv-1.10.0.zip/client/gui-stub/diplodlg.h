/* diplodlg.h -- PLACEHOLDER */
#ifndef FC__DIPLODLG_H
#define FC__DIPLODLG_H

#include "diplodlg_g.h"


#endif  /* FC__DIPLODLG_H */
