/* menu.c -- PLACEHOLDER */

#include "menu.h"


void
update_menus(void)
{
	/* PORTME */
}
