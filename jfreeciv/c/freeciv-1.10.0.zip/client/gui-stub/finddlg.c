/* finddlg.c -- PLACEHOLDER */

#include "finddlg.h"


void
popup_find_dialog(void)
{
	/* PORTME */
}
