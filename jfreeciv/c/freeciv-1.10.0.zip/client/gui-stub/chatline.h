/* chatline.h -- PLACEHOLDER */
#ifndef FC__CHATLINE_H
#define FC__CHATLINE_H

#include "chatline_g.h"


#endif  /* FC__CHATLINE_H */
