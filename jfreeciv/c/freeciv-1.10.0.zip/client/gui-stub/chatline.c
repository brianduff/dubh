/* chatline.c -- PLACEHOLDER */

#include "chatline.h"


void
append_output_window(char *astring)
{
	/* PORTME */
}

void
log_output_window(void)
{
	/* PORTME */
}

void
clear_output_window(void)
{
	/* PORTME */
}
