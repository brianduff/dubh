/* spaceshipdlg.c -- PLACEHOLDER */

#include "spaceshipdlg.h"


void
popup_spaceship_dialog(struct player *pplayer)
{
	/* PORTME */
}

void
popdown_spaceship_dialog(struct player *pplayer)
{
	/* PORTME */
}

void
refresh_spaceship_dialog(struct player *pplayer)
{
	/* PORTME */
}
