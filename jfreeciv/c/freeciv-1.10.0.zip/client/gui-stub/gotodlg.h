/* gotodlg.h -- PLACEHOLDER */
#ifndef FC__GOTODLG_H
#define FC__GOTODLG_H

#include "gotodlg_g.h"


#endif  /* FC__GOTODLG_H */
