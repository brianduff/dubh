/* messagewin.c -- PLACEHOLDER */

#include "messagewin.h"


void
popup_meswin_dialog(void)
{
	/* PORTME */
}

void
update_meswin_dialog(void)
{
	/* PORTME */
}

void
clear_notify_window(void)
{
	/* PORTME */
}

void
add_notify_window(struct packet_generic_message *packet)
{
	/* PORTME */
}

void
meswin_update_delay_on(void)
{
	/* PORTME */
}

void
meswin_update_delay_off(void)
{
	/* PORTME */
}
