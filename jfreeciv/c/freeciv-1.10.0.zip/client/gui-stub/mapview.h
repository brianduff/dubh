/* mapview.h -- PLACEHOLDER */
#ifndef FC__MAPVIEW_H
#define FC__MAPVIEW_H

#include "mapview_g.h"


#endif  /* FC__MAPVIEW_H */
