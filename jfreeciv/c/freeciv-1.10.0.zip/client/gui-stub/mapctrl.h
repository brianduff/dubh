/* mapctrl.h -- PLACEHOLDER */
#ifndef FC__MAPCTRL_H
#define FC__MAPCTRL_H

#include "mapctrl_g.h"


#endif  /* FC__MAPCTRL_H */
