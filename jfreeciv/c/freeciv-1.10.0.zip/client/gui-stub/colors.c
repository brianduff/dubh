/* colors.c -- PLACEHOLDER */

#include "colors.h"


void
init_color_system(void)
{
	/* PORTME */
}

void
color_error(void)
{
	/* PORTME */
}
