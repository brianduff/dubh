/* dialogs.h -- PLACEHOLDER */
#ifndef FC__DIALOGS_H
#define FC__DIALOGS_H

#include "dialogs_g.h"


#endif  /* FC__DIALOGS_H */
