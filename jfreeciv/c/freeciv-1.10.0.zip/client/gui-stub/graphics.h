/* graphics.h -- PLACEHOLDER */
#ifndef FC__GRAPHICS_H
#define FC__GRAPHICS_H

#include "graphics_g.h"


#endif  /* FC__GRAPHICS_H */
