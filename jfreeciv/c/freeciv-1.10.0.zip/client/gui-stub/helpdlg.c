/* helpdlg.c -- PLACEHOLDER */

#include "helpdlg.h"


void
popup_help_dialog(int item)
{
	/* PORTME */
}

void
popup_help_dialog_string(char *item)
{
	/* PORTME */
}

void
popup_help_dialog_typed(char *item, enum help_page_type htype)
{
	/* PORTME */
}

void
popdown_help_dialog(void)
{
	/* PORTME */
}
