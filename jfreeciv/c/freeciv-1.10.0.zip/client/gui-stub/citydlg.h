/* citydlg.h -- PLACEHOLDER */
#ifndef FC__CITYDLG_H
#define FC__CITYDLG_H

#include "citydlg_g.h"


#endif  /* FC__CITYDLG_H */
