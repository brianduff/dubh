/* gui_main.h -- PLACEHOLDER */
#ifndef FC__GUI_MAIN_H
#define FC__GUI_MAIN_H

#include "gui_main_g.h"


#endif  /* FC__GUI_MAIN_H */
