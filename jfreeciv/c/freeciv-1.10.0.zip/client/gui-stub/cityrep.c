/* cityrep.c -- PLACEHOLDER */

#include <stdlib.h>

#include "cityrep.h"


void
popup_city_report_dialog(int make_modal)
{
	/* PORTME */
}

void
city_report_dialog_update(void)
{
	/* PORTME */
}

void
city_report_dialog_update_city(struct city *pcity)
{
	/* PORTME */
}
