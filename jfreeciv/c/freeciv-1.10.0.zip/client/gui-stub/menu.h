/* menu.h -- PLACEHOLDER */
#ifndef FC__MENU_H
#define FC__MENU_H

#include "menu_g.h"


#endif  /* FC__MENU_H */
