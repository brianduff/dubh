/* messagedlg.c -- PLACEHOLDER */

#include "messagedlg.h"


void
popup_messageopt_dialog(void)
{
	/* PORTME */
}
