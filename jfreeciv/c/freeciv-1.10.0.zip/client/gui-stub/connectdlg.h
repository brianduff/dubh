/* connectdlg.h -- PLACEHOLDER */
#ifndef FC__CONNECTDLG_H
#define FC__CONNECTDLG_H

#include "connectdlg_g.h"


#endif  /* FC__CONNECTDLG_H */
