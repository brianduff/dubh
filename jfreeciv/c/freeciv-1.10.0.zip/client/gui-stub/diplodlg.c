/* diplodlg.c -- PLACEHOLDER */

#include "diplodlg.h"


void
handle_diplomacy_accept_treaty(struct packet_diplomacy_info *pa)
{
	/* PORTME */
}

void
handle_diplomacy_init_meeting(struct packet_diplomacy_info *pa)
{
	/* PORTME */
}

void
handle_diplomacy_create_clause(struct packet_diplomacy_info *pa)
{
	/* PORTME */
}

void
handle_diplomacy_cancel_meeting(struct packet_diplomacy_info *pa)
{
	/* PORTME */
}

void
handle_diplomacy_remove_clause(struct packet_diplomacy_info *pa)
{
	/* PORTME */
}
