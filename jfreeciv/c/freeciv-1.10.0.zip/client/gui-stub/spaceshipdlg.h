/* spaceshipdlg.h -- PLACEHOLDER */
#ifndef FC__SPACESHIPDLG_H
#define FC__SPACESHIPDLG_H

#include "spaceshipdlg_g.h"


#endif  /* FC__SPACESHIPDLG_H */
