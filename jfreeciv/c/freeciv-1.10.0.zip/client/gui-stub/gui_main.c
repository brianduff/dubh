/* gui_main.c -- PLACEHOLDER */

#include <stdio.h>

#include "gui_main.h"


void
ui_main(int argc, char *argv[])
{
	/* PORTME */
	fprintf( stderr, "Freeciv rules!\n" );
}

void
enable_turn_done_button(void)
{
	/* PORTME */
}

void
add_net_input(int sock)
{
	/* PORTME */
}

void
remove_net_input(void)
{
	/* PORTME */
}
