/* citydlg.c -- PLACEHOLDER */

#include "citydlg.h"


void
popup_city_dialog(struct city *pcity, int make_modal)
{
	/* PORTME */
}

void
popdown_city_dialog(struct city *pcity)
{
	/* PORTME */
}

void
popdown_all_city_dialogs(void)
{
	/* PORTME */
}

void
refresh_city_dialog(struct city *pcity)
{
	/* PORTME */
}

void
refresh_unit_city_dialogs(struct unit *punit)
{
	/* PORTME */
}
