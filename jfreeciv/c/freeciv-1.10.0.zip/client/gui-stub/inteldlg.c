/* inteldlg.c -- PLACEHOLDER */

#include "inteldlg.h"


void
popup_intel_dialog(struct player *p)
{
	/* PORTME */
}
