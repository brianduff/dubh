/* mapctrl.c -- PLACEHOLDER */

#include <stdlib.h>

#include "mapctrl_g.h"

struct city *city_workers_display = NULL;


void
popup_newcity_dialog(struct unit *punit, char *suggestname)
{
	/* PORTME */
}

void
set_turn_done_button_state( int state )
{
	/* PORTME */
}
