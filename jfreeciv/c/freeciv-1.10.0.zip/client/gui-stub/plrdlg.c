/* plrdlg.c -- PLACEHOLDER */

#include "plrdlg.h"


void
popup_players_dialog(void)
{
	/* PORTME */
}

void
update_players_dialog(void)
{
	/* PORTME */
}
