/* gotodlg.c -- PLACEHOLDER */

#include "gotodlg.h"


void
popup_goto_dialog(void)
{
	/* PORTME */
}
