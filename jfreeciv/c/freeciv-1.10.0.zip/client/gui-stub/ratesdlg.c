/* ratesdlg.c -- PLACEHOLDER */

#include "ratesdlg.h"


void
popup_rates_dialog(void)
{
	/* PORTME */
}
