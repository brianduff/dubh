/* connectdlg.c -- PLACEHOLDER */

#include "connectdlg.h"


void
gui_server_connect(void)
{
	/* PORTME */
}
