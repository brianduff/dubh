/* dialogs.c -- PLACEHOLDER */

#include "dialogs.h"


void
popup_notify_goto_dialog(char *headline, char *lines, int x, int y)
{
	/* PORTME */
}

void
popup_notify_dialog(char *caption, char *headline, char *lines)
{
	/* PORTME */
}

void
popup_races_dialog(void)
{
	/* PORTME */
}

void
popdown_races_dialog(void)
{
	/* PORTME */
}

void
popup_unit_select_dialog(struct tile *ptile)
{
	/* PORTME */
}

void
races_toggles_set_sensitive(int bits1, int bits2)
{
	/* PORTME */
}

void
popup_revolution_dialog(void)
{
	/* PORTME */
}

void
popup_government_dialog(void)
{
	/* PORTME */
}

void
popup_caravan_dialog(struct unit *punit,
                          struct city *phomecity, struct city *pdestcity)
{
	/* PORTME */
}

void
popup_diplomat_dialog(struct unit *punit, int dest_x, int dest_y)
{
	/* PORTME */
}

void
popup_incite_dialog(struct city *pcity)
{
	/* PORTME */
}

void
popup_bribe_dialog(struct unit *punit)
{
	/* PORTME */
}

void
popup_pillage_dialog(struct unit *punit, int may_pillage)
{
	/* PORTME */
}

void
process_caravan_arrival(struct unit *punit)
{
	/* PORTME */
}
